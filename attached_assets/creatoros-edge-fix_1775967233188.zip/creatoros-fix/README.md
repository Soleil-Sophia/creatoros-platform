# CreatorOS — Edge Function Fix

## Was das Problem war

Supabase CLI erwartet den Folder-Namen identisch mit dem Function-Namen:

```
✅ RICHTIG:  supabase/functions/make-server-add905f8/index.ts
❌ FALSCH:   supabase/functions/server/index.tsx
```

`supabase functions deploy make-server-add905f8` schaut in `supabase/functions/make-server-add905f8/` —
dieser Folder existierte nicht, deshalb der Fehler.

---

## Fix einspielen

1. Diesen Folder ins Repo kopieren:
   ```
   supabase/functions/make-server-add905f8/
   ├── index.ts        ← neuer Server (ersetzt functions/server/index.tsx)
   └── kv_store.tsx    ← unverändert (aus functions/server/kv_store.tsx kopiert)
   ```

2. Den alten `supabase/functions/server/` Folder kannst du löschen oder behalten — er wird nicht mehr genutzt.

---

## Deploy

```bash
supabase functions deploy make-server-add905f8
```

---

## OpenAI Key setzen (falls noch nicht done)

Im [Supabase Dashboard](https://supabase.com/dashboard/project/ylulrtnvohxpriyucyqw):
→ **Edge Functions** → **Secrets** → Add Secret:

```
Name:  OPENAI_API_KEY
Value: sk-proj-...dein-key...
```

---

## Testen nach Deployment

### 1. Health Check (kein Auth nötig)
```bash
curl https://ylulrtnvohxpriyucyqw.supabase.co/functions/v1/make-server-add905f8/health
```
Erwartete Antwort:
```json
{"status":"ok","version":"mvp1"}
```

### 2. Brand Profile speichern (mit Auth)
```bash
curl -X POST \
  https://ylulrtnvohxpriyucyqw.supabase.co/functions/v1/make-server-add905f8/brand-profile \
  -H 'Authorization: Bearer <USER_JWT_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{
    "brandName": "TestBrand",
    "mission": "Help creators build systems",
    "voiceTone": "Direct & Motivational"
  }'
```
Erwartete Antwort:
```json
{"success":true}
```

### 3. Content generieren (mit Auth + OpenAI Key)
```bash
curl -X POST \
  https://ylulrtnvohxpriyucyqw.supabase.co/functions/v1/make-server-add905f8/content/generate \
  -H 'Authorization: Bearer <USER_JWT_TOKEN>' \
  -H 'Content-Type: application/json' \
  -d '{
    "offer": "Content OS für Solo-Creator",
    "platform": "LinkedIn",
    "audience": "Self-employed coaches",
    "goal": "Build awareness",
    "tone": "Conversational",
    "outputType": "Full Content Suite"
  }'
```

### Den USER_JWT_TOKEN bekommst du so:
```js
// Im Browser-Console nach Login:
const { data } = await supabase.auth.getSession()
console.log(data.session.access_token)
```

---

## Mögliche Fehler & Fixes

| Error | Ursache | Fix |
|---|---|---|
| `Function not found` | Folder-Name falsch | Sicherstellen: `functions/make-server-add905f8/index.ts` |
| `Unauthorized` | Kein/falscher JWT | User einloggen, `access_token` aus Session nehmen |
| `OPENAI_API_KEY not set` | Secret fehlt | Im Dashboard → Edge Functions → Secrets eintragen |
| `AI generation failed` | OpenAI Fehler | API Key prüfen, Logs in Dashboard ansehen |
| Import error `kv_store` | kv_store.tsx fehlt im Folder | Beide Dateien müssen im selben Folder sein |

---

## Supabase Function Logs ansehen

```bash
supabase functions logs make-server-add905f8
```

Oder im Dashboard: **Edge Functions** → `make-server-add905f8` → **Logs**

---

*Fix erstellt: 2026-04-12*
